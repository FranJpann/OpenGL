rm Projet.exe
gcc Files/main.c Files/init.c Files/init.h Files/actions.c Files/actions.h Files/touches.h Files/playmobil.c Files/playmobil.h Files/ppm.c Files/ppm.h Files/texture.c Files/texture.h -lm -lGL -lGLU -lglut -o Projet.exe

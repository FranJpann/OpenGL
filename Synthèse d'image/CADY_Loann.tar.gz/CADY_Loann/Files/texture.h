#include <stdio.h>
#include <stdlib.h>
#include <GL/gl.h>

void loadTexture();